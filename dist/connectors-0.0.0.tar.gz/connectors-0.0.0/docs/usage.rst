=====
Usage
=====

To use connectors in a project::

	import connectors
