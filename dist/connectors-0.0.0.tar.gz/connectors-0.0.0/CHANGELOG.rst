
Changelog
=========

0.0.0 (2022-01-12)
------------------

* First release on PyPI.
